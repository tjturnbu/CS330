﻿// Tyler Turnbull
// 12 August 2023
// SNHU CS-330 Comp Graphic and Visualization

#include <glad/glad.h>
#include <GLFW/glfw3.h>

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <glm/gtx/normal.hpp>

#include "shader.h"
#include "camera.h"

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

#include <iostream>


void framebuffer_size_callback(GLFWwindow* window, int width, int height);
void mouse_callback(GLFWwindow* window, double xpos, double ypos);
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset);
void processInput(GLFWwindow* window);
unsigned int loadTexture(const char* path);

// settings
const unsigned int SCR_WIDTH = 800;
const unsigned int SCR_HEIGHT = 600;

// camera
Camera camera(glm::vec3(0.0f, 0.0f, 3.0f));
float lastX = SCR_WIDTH / 2.0f;
float lastY = SCR_HEIGHT / 2.0f;
bool firstMouse = true;

// timing
float deltaTime = 0.0f;
float lastFrame = 0.0f;

bool isOrtho = false;


void addVertex(std::vector<float>& vertices, float x, float y, float z)
{
	vertices.push_back(x);
	vertices.push_back(y);
	vertices.push_back(z);
}

void addNormal(std::vector<float>& normals, float nx, float ny, float nz)
{
	normals.push_back(nx);
	normals.push_back(ny);
	normals.push_back(nz);
}

void addTexCoord(std::vector<float>& texCoords, float s, float t)
{
	texCoords.push_back(s);
	texCoords.push_back(t);
}

void addIndices(std::vector<unsigned int>& indices, unsigned int i1, unsigned int i2, unsigned int i3)
{
	indices.push_back(i1);
	indices.push_back(i2);
	indices.push_back(i3);
}

std::vector<float> computeFaceNormal(float x1, float y1, float z1,  // v1
	float x2, float y2, float z2,  // v2
	float x3, float y3, float z3)  // v3
{
	const float EPSILON = 0.000001f;

	std::vector<float> normal(3, 0.0f);     // default return value (0,0,0)
	float nx, ny, nz;

	// find 2 edge vectors: v1-v2, v1-v3
	float ex1 = x2 - x1;
	float ey1 = y2 - y1;
	float ez1 = z2 - z1;
	float ex2 = x3 - x1;
	float ey2 = y3 - y1;
	float ez2 = z3 - z1;

	// cross product: e1 x e2
	nx = ey1 * ez2 - ez1 * ey2;
	ny = ez1 * ex2 - ex1 * ez2;
	nz = ex1 * ey2 - ey1 * ex2;

	// normalize only if the length is > 0
	float length = sqrtf(nx * nx + ny * ny + nz * nz);
	if (length > EPSILON)
	{
		// normalize
		float lengthInv = 1.0f / length;
		normal[0] = nx * lengthInv;
		normal[1] = ny * lengthInv;
		normal[2] = nz * lengthInv;
	}

	return normal;
}

int generateCylinder(GLuint* VAO, float baseRadius, float topRadius, float height, int sectorCount)
{
	std::vector<float> vertices;
	std::vector<float> normals;
	std::vector<float> texCoords;

	std::vector<unsigned int> indices;

	unsigned int baseIndex;                 // starting index of base
	unsigned int topIndex;                  // starting index of top

	int stackCount = 1;

	std::vector<float> unitCircleVertices;

	const float PI = acos(-1.0f);
	float sectorStep = 2 * PI / sectorCount;
	float sectorAngle;  // radian

	for (int i = 0; i <= sectorCount; ++i)
	{
		sectorAngle = i * sectorStep;
		unitCircleVertices.push_back(cos(sectorAngle)); // x
		unitCircleVertices.push_back(sin(sectorAngle)); // y
		unitCircleVertices.push_back(0);                // z
	}


	// tmp vertex definition (x,y,z,s,t)
	struct Vertex
	{
		float x, y, z, s, t;
	};
	std::vector<Vertex> tmpVertices;

	int i, j, k;    // indices
	float x, y, z, s, t, radius;

	// put tmp vertices of cylinder side to array by scaling unit circle
	//NOTE: start and end vertex positions are same, but texcoords are different
	//      so, add additional vertex at the end point
	for (i = 0; i <= stackCount; ++i)
	{
		z = -(height * 0.5f) + (float)i / stackCount * height;      // vertex position z
		radius = baseRadius + (float)i / stackCount * (topRadius - baseRadius);     // lerp
		t = 1.0f - (float)i / stackCount;   // top-to-bottom

		for (j = 0, k = 0; j <= sectorCount; ++j, k += 3)
		{
			x = unitCircleVertices[k];
			y = unitCircleVertices[k + 1];
			s = (float)j / sectorCount;

			Vertex vertex;
			vertex.x = x * radius;
			vertex.y = y * radius;
			vertex.z = z;
			vertex.s = s;
			vertex.t = t;
			tmpVertices.push_back(vertex);
		}
	}


	Vertex v1, v2, v3, v4;      // 4 vertex positions v1, v2, v3, v4
	std::vector<float> n;       // 1 face normal
	int vi1, vi2;               // indices
	int index = 0;

	// v2-v4 <== stack at i+1
	// | \ |
	// v1-v3 <== stack at i
	for (i = 0; i < stackCount; ++i)
	{
		vi1 = i * (sectorCount + 1);            // index of tmpVertices
		vi2 = (i + 1) * (sectorCount + 1);

		for (j = 0; j < sectorCount; ++j, ++vi1, ++vi2)
		{
			v1 = tmpVertices[vi1];
			v2 = tmpVertices[vi2];
			v3 = tmpVertices[vi1 + 1];
			v4 = tmpVertices[vi2 + 1];

			n = computeFaceNormal(v1.x, v1.y, v1.z, v3.x, v3.y, v3.z, v2.x, v2.y, v2.z);

			// put quad vertices: v1-v2-v3-v4
			addVertex(vertices, v1.x, v1.y, v1.z);
			addVertex(vertices, v2.x, v2.y, v2.z);
			addVertex(vertices, v3.x, v3.y, v3.z);
			addVertex(vertices, v4.x, v4.y, v4.z);

			addTexCoord(texCoords, v1.s * 3.0f, v1.t * 1.0f);
			addTexCoord(texCoords, v2.s * 3.0f, v2.t * 1.0f);
			addTexCoord(texCoords, v3.s * 3.0f, v3.t * 1.0f);
			addTexCoord(texCoords, v4.s * 3.0f, v4.t * 1.0f);

			for (k = 0; k < 4; ++k)  // same normals for all 4 vertices
			{
				addNormal(normals, n[0], n[1], n[2]);
			}

			// put indices of a quad
			addIndices(indices, index, index + 2, index + 1);    // v1-v3-v2
			addIndices(indices, index + 1, index + 2, index + 3);    // v2-v3-v4

			index += 4;     // for next
		}
	}

	// remember where the base index starts
	baseIndex = (unsigned int)indices.size();
	unsigned int baseVertexIndex = (unsigned int)vertices.size() / 3;

	// put vertices of base of cylinder
	z = -height * 0.5f;
	addVertex(vertices, 0, 0, z);
	addNormal(normals, 0, 0, -1);
	addTexCoord(texCoords, 0.5f, 0.5f);
	for (i = 0, j = 0; i < sectorCount; ++i, j += 3)
	{
		x = unitCircleVertices[j];
		y = unitCircleVertices[j + 1];
		addVertex(vertices, x * baseRadius, y * baseRadius, z);
		addNormal(normals, 0, 0, -1);
		addTexCoord(texCoords, -x * 0.5f + 0.5f, -y * 0.5f + 0.5f); // flip horizontal
	}

	// put indices for base
	for (i = 0, k = baseVertexIndex + 1; i < sectorCount; ++i, ++k)
	{
		if (i < sectorCount - 1)
			addIndices(indices, baseVertexIndex, k + 1, k);
		else
			addIndices(indices, baseVertexIndex, baseVertexIndex + 1, k);
	}

	// remember where the top index starts
	topIndex = (unsigned int)indices.size();
	unsigned int topVertexIndex = (unsigned int)vertices.size() / 3;

	// put vertices of top of cylinder
	z = height * 0.5f;
	addVertex(vertices, 0, 0, z);
	addNormal(normals, 0, 0, 1);
	addTexCoord(texCoords, 0.5f, 0.5f);
	for (i = 0, j = 0; i < sectorCount; ++i, j += 3)
	{
		x = unitCircleVertices[j];
		y = unitCircleVertices[j + 1];
		addVertex(vertices, x * topRadius, y * topRadius, z);
		addNormal(normals, 0, 0, 1);
		addTexCoord(texCoords, x * 0.5f + 0.5f, -y * 0.5f + 0.5f);
	}

	for (i = 0, k = topVertexIndex + 1; i < sectorCount; ++i, ++k)
	{
		if (i < sectorCount - 1)
			addIndices(indices, topVertexIndex, k, k + 1);
		else
			addIndices(indices, topVertexIndex, k, topVertexIndex + 1);
	}

	std::vector<float> interleavedVertices;

	std::size_t i1, j1;
	std::size_t count = vertices.size();
	for (i1 = 0, j1 = 0; i1 < count; i1 += 3, j1 += 2)
	{
		interleavedVertices.insert(interleavedVertices.end(), &vertices[i1], &vertices[i1] + 3);

		interleavedVertices.insert(interleavedVertices.end(), &normals[i1], &normals[i1] + 3);

		interleavedVertices.insert(interleavedVertices.end(), &texCoords[j1], &texCoords[j1] + 2);
	}


	glGenVertexArrays(1, VAO);
	glBindVertexArray(*VAO);

	GLuint crownVBO;
	glGenBuffers(1, &crownVBO);
	glBindBuffer(GL_ARRAY_BUFFER, crownVBO);
	glBufferData(GL_ARRAY_BUFFER,
		(unsigned int)interleavedVertices.size() * sizeof(float),
		&interleavedVertices[0],
		GL_STATIC_DRAW);

	GLuint crownIBO;
	glGenBuffers(1, &crownIBO);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, crownIBO);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER,
		indices.size() * sizeof(unsigned int),
		&indices[0],
		GL_STATIC_DRAW);

	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
	glEnableVertexAttribArray(2);


	return indices.size();

}


int generatePlane(GLuint* VAO)
{
	std::vector<float> planeVertices = {
		-1.0f, 0.0f, -1.0f,		0.0f, 1.0f, 0.0f,		0.0f, 0.0f,
		-1.0f, 0.0f, 1.0f,		0.0f, 1.0f, 0.0f,		2.0f, 0.0f,
		1.0f, 0.0f, 1.0f,		0.0f, 1.0f, 0.0f,		2.0f, 2.0f,
		1.0f, 0.0f, -1.0f,		0.0f, 1.0f, 0.0f,		0.0f, 2.0f,
	};

	std::vector<unsigned int> planeIndices = {
		0, 1, 2,
		0, 2, 3
	};

	unsigned int planeVBO, planeEBO;

	glGenVertexArrays(1, VAO);
	glGenBuffers(1, &planeVBO);
	glGenBuffers(1, &planeEBO);

	glBindVertexArray(*VAO);
	glBindBuffer(GL_ARRAY_BUFFER, planeVBO);
	glBufferData(GL_ARRAY_BUFFER, planeVertices.size() * sizeof(float), &planeVertices[0], GL_STATIC_DRAW);

	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
	glEnableVertexAttribArray(2);

	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, planeEBO);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, planeIndices.size() * sizeof(unsigned int), &planeIndices[0], GL_STATIC_DRAW);

	return planeIndices.size();
}


int generatePyramid(GLuint* VAO)
{
	std::vector<float> pyramidTexCoords = {
		0.0f, 0.0f,    0.0f,
		1.0f, 0.0f,    0.0f,
		0.5f, 1.0f,    0.0f,


		0.0f, 0.0f,    0.0f,
		1.0f, 0.0f,    0.0f,
		0.5f, 1.0f,    0.0f,


		0.0f, 0.0f,    0.0f,
		1.0f, 0.0f,    0.0f,
		0.5f, 1.0f,    0.0f,


		0.0f, 0.0f,    0.0f,
		1.0f, 0.0f,    0.0f,
		0.5f, 1.0f,    0.0f,


		0.0f, 0.0f,    0.0f,
		1.0f, 0.0f,    0.0f,
		1.0f, 1.0f,    0.0f,

		0.0f, 0.0f,    0.0f,
		1.0f, 1.0f,    0.0f,
		0.0f, 1.0f,    0.0f,
	};



	std::vector<float> pyramidVertices = {
		// Front face
		-0.5f, 0.0f, -0.5f,
		0.5f, 0.0f, -0.5f,
		0.0f, 1.0f, 0.0f,

		// Right face
		0.5f, 0.0f, -0.5f,
		0.5f, 0.0f, 0.5f,
		0.0f, 1.0f, 0.0f,

		// Back face
		0.5f, 0.0f, 0.5f,
		-0.5f, 0.0f, 0.5f,
		0.0f, 1.0f, 0.0f,

		// Left face
		-0.5f, 0.0f, 0.5f,
		-0.5f, 0.0f, -0.5f,
		0.0f, 1.0f, 0.0f,

		// Bottom face (square)
		-0.5f, 0.0f, -0.5f,
		0.5f, 0.0f, -0.5f,
		0.5f, 0.0f, 0.5f,

		-0.5f, 0.0f, -0.5f,
		0.5f, 0.0f, 0.5f,
		-0.5f, 0.0f, 0.5f,
	};



	// Calculate normals for each face
	std::vector<glm::vec3> faceNormals;
	for (size_t i = 0; i < pyramidVertices.size(); i += 9) {
		glm::vec3 v1(pyramidVertices[i], pyramidVertices[i + 1], pyramidVertices[i + 2]);
		glm::vec3 v2(pyramidVertices[i + 3], pyramidVertices[i + 4], pyramidVertices[i + 5]);
		glm::vec3 v3(pyramidVertices[i + 6], pyramidVertices[i + 7], pyramidVertices[i + 8]);

		glm::vec3 normal = glm::triangleNormal(v1, v2, v3);
		faceNormals.push_back(normal);
	}


	std::vector<float> pyramidInterleavedData;
	for (size_t i = 0; i < pyramidVertices.size(); i += 3) {
		pyramidInterleavedData.push_back(pyramidVertices[i]);
		pyramidInterleavedData.push_back(pyramidVertices[i + 1]);
		pyramidInterleavedData.push_back(pyramidVertices[i + 2]);

		glm::vec3 normal = faceNormals[i / 9]; // Assuming there is one normal per vertex
		pyramidInterleavedData.push_back(-normal.x);
		pyramidInterleavedData.push_back(-normal.y);
		pyramidInterleavedData.push_back(-normal.z);

		pyramidInterleavedData.push_back(pyramidTexCoords[i]);
		pyramidInterleavedData.push_back(pyramidTexCoords[i + 1]);
	}


	unsigned int pyramidVBO;

	glGenVertexArrays(1, VAO);
	glGenBuffers(1, &pyramidVBO);

	glBindVertexArray(*VAO);
	glBindBuffer(GL_ARRAY_BUFFER, pyramidVBO);
	glBufferData(GL_ARRAY_BUFFER, pyramidInterleavedData.size() * sizeof(float), &pyramidInterleavedData[0], GL_STATIC_DRAW);

	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);

	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);

	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
	glEnableVertexAttribArray(2);

	return pyramidInterleavedData.size() / 8;
}


int generateTorus(GLuint *VAO, float r, float R, int nr, int nR)
{
	std::vector<float> vertices;
	std::vector<float> normals;
	std::vector<float> texCoords;

	const float PI = acos(-1.0f);
	float du = 2 * PI / nR;
	float dv = 2 * PI / nr;

	for (size_t i = 0; i < nR; i++) {

		float u = i * du;

		for (size_t j = 0; j <= nr; j++) {

			float v = (j % nr) * dv;

			for (size_t k = 0; k < 2; k++)
			{
				float uu = u + k * du;
				// compute vertex
				float x = (R + r * cos(v)) * cos(uu);
				float y = (R + r * cos(v)) * sin(uu);
				float z = r * sin(v);

				// add vertex 
				vertices.push_back(x);
				vertices.push_back(y);
				vertices.push_back(z);

				// compute normal 
				float nx = cos(v) * cos(uu);
				float ny = cos(v) * sin(uu);
				float nz = sin(v);

				// add normal 
				normals.push_back(nx);
				normals.push_back(ny);
				normals.push_back(nz);

				// compute texture coords
				float tx = uu / (2 * PI);
				float ty = v / (2 * PI);

				// add tex coords
				texCoords.push_back(tx);
				texCoords.push_back(ty);

			}
			v += dv;

		}
	}

	std::vector<float> interleavedVertices;

	std::size_t i1, j1;
	std::size_t count = vertices.size();
	for (i1 = 0, j1 = 0; i1 < count; i1 += 3, j1 += 2)
	{
		interleavedVertices.insert(interleavedVertices.end(), &vertices[i1], &vertices[i1] + 3);

		interleavedVertices.insert(interleavedVertices.end(), &normals[i1], &normals[i1] + 3);

		interleavedVertices.insert(interleavedVertices.end(), &texCoords[j1], &texCoords[j1] + 2);
	}


	unsigned int torusVBO;

	glGenVertexArrays(1, VAO);
	glGenBuffers(1, &torusVBO);

	glBindVertexArray(*VAO);
	glBindBuffer(GL_ARRAY_BUFFER, torusVBO);
	glBufferData(GL_ARRAY_BUFFER, interleavedVertices.size() * sizeof(float), &interleavedVertices[0], GL_STATIC_DRAW);

	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);

	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);

	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
	glEnableVertexAttribArray(2);


	return interleavedVertices.size() / 8;
}


int generateCube(GLuint* VAO)
{
	std::vector<float> vertices = {
		// positions          // normals           // texture coords

		//back side
		-0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f,  0.0f,
		 0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f,  0.0f,
		 0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f,  1.0f,
		 0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f,  1.0f,
		-0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f,  1.0f,
		-0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f,  0.0f,

		//front side
		-0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f,  0.0f,
		 0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f,  0.0f,
		 0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f,  1.0f,
		 0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f,  1.0f,
		-0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f,  1.0f,
		-0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f,  0.0f,


		////left side
		-0.5f,  0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  1.0f,  0.0f,
		-0.5f,  0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  1.0f,  1.0f,
		-0.5f, -0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  0.0f,  1.0f,
		-0.5f, -0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  0.0f,  1.0f,
		-0.5f, -0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  0.0f,  0.0f,
		-0.5f,  0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  1.0f,  0.0f,

		//right side
		 0.5f,  0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  1.0f,  0.0f,
		 0.5f,  0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  1.0f,  1.0f,
		 0.5f, -0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  0.0f,  1.0f,
		 0.5f, -0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  0.0f,  1.0f,
		 0.5f, -0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  0.0f,  0.0f,
		 0.5f,  0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  1.0f,  0.0f,

		//bottom side
		-0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,  0.0f,  1.0f,
		 0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,  1.0f,  1.0f,
		 0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,  1.0f,  0.0f,
		 0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,  1.0f,  0.0f,
		-0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,  0.0f,  0.0f,
		-0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,  0.0f,  1.0f,

		//top side
		-0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,  0.0f,  1.0f,
		 0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,  1.0f,  1.0f,
		 0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,  1.0f,  0.0f,
		 0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,  1.0f,  0.0f,
		-0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,  0.0f,  0.0f,
		-0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,  0.0f,  1.0f
	};

	unsigned int cubeVBO;

	glGenVertexArrays(1, VAO);
	glGenBuffers(1, &cubeVBO);

	glBindVertexArray(*VAO);
	glBindBuffer(GL_ARRAY_BUFFER, cubeVBO);
	glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(float), &vertices[0], GL_STATIC_DRAW);

	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);

	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);

	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
	glEnableVertexAttribArray(2);


	return vertices.size() / 8;

}


int generateSphere(GLuint* VAO, int stacks, int slices)
{
	// clear memory of prev arrays
	std::vector<float> vertices;
	std::vector<float> normals;
	std::vector<float> texCoords;

	const float PI = acos(-1.0f);

	for (int i = 0; i <= stacks; ++i) {
		float theta = i * PI / stacks;
		float sinTheta = std::sin(theta);
		float cosTheta = std::cos(theta);

		for (int j = 0; j <= slices; ++j) {
			float phi = j * 2 * PI / slices;
			float sinPhi = std::sin(phi);
			float cosPhi = std::cos(phi);

			float x = cosPhi * sinTheta;
			float y = cosTheta;
			float z = sinPhi * sinTheta;
			float u = 1 - (j / static_cast<float>(slices));
			float v = i / static_cast<float>(stacks);

			vertices.push_back(x);
			vertices.push_back(y);
			vertices.push_back(z);

			normals.push_back(x);
			normals.push_back(y);
			normals.push_back(z);

			texCoords.push_back(u);
			texCoords.push_back(v);
		}
	}


	std::vector<float> interleavedVertices;

	std::size_t i1, j1;
	std::size_t count = vertices.size();
	for (i1 = 0, j1 = 0; i1 < count; i1 += 3, j1 += 2)
	{
		interleavedVertices.insert(interleavedVertices.end(), &vertices[i1], &vertices[i1] + 3);

		interleavedVertices.insert(interleavedVertices.end(), &normals[i1], &normals[i1] + 3);

		interleavedVertices.insert(interleavedVertices.end(), &texCoords[j1], &texCoords[j1] + 2);
	}

	std::vector<unsigned int> indices;

	for (int i = 0; i < stacks; ++i) {
		int startIndex = i * (slices + 1);
		int nextStartIndex = (i + 1) * (slices + 1);

		for (int j = 0; j < slices; ++j) {
			indices.push_back(startIndex + j);
			indices.push_back(nextStartIndex + j);
			indices.push_back(startIndex + j + 1);

			indices.push_back(startIndex + j + 1);
			indices.push_back(nextStartIndex + j);
			indices.push_back(nextStartIndex + j + 1);
		}
	}



	unsigned int sphereVBO;

	glGenVertexArrays(1, VAO);
	glGenBuffers(1, &sphereVBO);

	glBindVertexArray(*VAO);
	glBindBuffer(GL_ARRAY_BUFFER, sphereVBO);
	glBufferData(GL_ARRAY_BUFFER, interleavedVertices.size() * sizeof(float), &interleavedVertices[0], GL_STATIC_DRAW);

	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);

	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);

	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
	glEnableVertexAttribArray(2);

	unsigned int ibo;
	glGenBuffers(1, &ibo);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size() * sizeof(unsigned int), indices.data(), GL_STATIC_DRAW);


	return indices.size();
}


void keyCallback(GLFWwindow* window, int key, int scancode, int action, int mods) {
	if (action == GLFW_RELEASE) {
		// Key release event handling
		if (key == GLFW_KEY_P) {
			isOrtho = !isOrtho;

			if (isOrtho)
				camera.ResetCamera();
		}
	}
}




int main()
{
	// glfw: initialize and configure
	// ------------------------------
	glfwInit();
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

	// glfw window creation
	// --------------------
	GLFWwindow* window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, "LearnOpenGL", NULL, NULL);
	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return -1;
	}
	glfwMakeContextCurrent(window);
	glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
	glfwSetCursorPosCallback(window, mouse_callback);
	glfwSetScrollCallback(window, scroll_callback);
	glfwSetKeyCallback(window, keyCallback);


	// tell GLFW to capture our mouse
	glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

	// glad: load all OpenGL function pointers
	// ---------------------------------------
	if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
	{
		std::cout << "Failed to initialize GLAD" << std::endl;
		return -1;
	}

	// configure global opengl state
	// -----------------------------
	glEnable(GL_DEPTH_TEST);

	Shader lightingShader("shaderfiles/lighting.vs", "shaderfiles/lighting.fs");

	GLuint crownBaseVAO = 0;
	int crownBaseVertexCount = generateCylinder(&crownBaseVAO, 1.0f, 1.0f, 1.0f, 36);

	GLuint crownTopVAO = 0;
	int crownTopVertexCount = generateCylinder(&crownTopVAO, 1.0f, 0.0f, 0.5f, 36);

	GLuint planeVAO = 0;
	int planeVertexCount = generatePlane(&planeVAO);

	GLuint pyramidVAO = 0;
	int pyramidVertexCount = generatePyramid(&pyramidVAO);

	GLuint torusVAO = 0;
	int torusVertexCount = generateTorus(&torusVAO, 0.5, 2, 64, 64);

	GLuint cubeVAO = 0;
	int cubeVertexCount = generateCube(&cubeVAO);

	GLuint sphereVAO = 0;
	int sphereVertexCount = generateSphere(&sphereVAO, 50, 50);

	GLuint cylinderVAO = 0;
	int cylinderVertexCount = generateCylinder(&cylinderVAO, 1.0f, 1.0f, 1.0f, 36);



	std::vector<float> stickHolderVertices = {
		// positions          // normals           // texture coords

		//back side-top
		-0.6f, -0.0f,  -0.5f,  0.0f,  0.0f,  1.0f,  0.0f,  0.0f,
		 0.6f, -0.0f,  -0.5f,  0.0f,  0.0f,  1.0f,  1.0f,  0.0f,
		 0.5f,  0.5f,  -0.5f,  0.0f,  0.0f,  1.0f,  1.0f,  1.0f,

		 0.5f,  0.5f,  -0.5f,  0.0f,  0.0f,  1.0f,  1.0f,  1.0f,
		-0.5f,  0.5f,  -0.5f,  0.0f,  0.0f,  1.0f,  0.0f,  1.0f,
		-0.6f, -0.0f,  -0.5f,  0.0f,  0.0f,  1.0f,  0.0f,  0.0f,

		//back side-bottom
		-0.5f, -0.5f,  -0.5f,  0.0f,  0.0f,  1.0f,  0.0f,  0.0f,
		 0.5f, -0.5f,  -0.5f,  0.0f,  0.0f,  1.0f,  1.0f,  0.0f,
		 0.6f,  0.0f,  -0.5f,  0.0f,  0.0f,  1.0f,  1.0f,  1.0f,

		 0.6f,  0.0f,  -0.5f,  0.0f,  0.0f,  1.0f,  1.0f,  1.0f,
		-0.6f,  0.0f,  -0.5f,  0.0f,  0.0f,  1.0f,  0.0f,  1.0f,
		-0.5f, -0.5f,  -0.5f,  0.0f,  0.0f,  1.0f,  0.0f,  0.0f,

		//front side-top
		-0.6f, -0.0f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f,  0.0f,
		 0.6f, -0.0f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f,  0.0f,
		 0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f,  1.0f,

		 0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f,  1.0f,
		-0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f,  1.0f,
		-0.6f, -0.0f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f,  0.0f,

		//front side-bottom
		-0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f,  0.0f,
		 0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f,  0.0f,
		 0.6f,  0.0f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f,  1.0f,

		 0.6f,  0.0f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f,  1.0f,
		-0.6f,  0.0f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f,  1.0f,
		-0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f,  0.0f,


		//left side-top
		-0.5f,  0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  1.0f,  0.0f,
		-0.5f,  0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  1.0f,  1.0f,
		-0.6f, 0.0f, -0.5f, -1.0f,  0.0f,  0.0f,  0.0f,  1.0f,

		-0.6f, 0.0f, -0.5f, -1.0f,  0.0f,  0.0f,  0.0f,  1.0f,
		-0.6f, 0.0f,  0.5f, -1.0f,  0.0f,  0.0f,  0.0f,  0.0f,
		-0.5f,  0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  1.0f,  0.0f,



		//left side-bottom
		-0.5f,  -0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  1.0f,  0.0f,
		-0.5f,  -0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  1.0f,  1.0f,
		-0.6f,	-0.0f, -0.5f, -1.0f,  0.0f,  0.0f,  0.0f,  1.0f,

		-0.6f,	-0.0f, -0.5f, -1.0f,  0.0f,  0.0f,  0.0f,  1.0f,
		-0.6f,	-0.0f,  0.5f, -1.0f,  0.0f,  0.0f,  0.0f,  0.0f,
		-0.5f,  -0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  1.0f,  0.0f,




		//right side-top
		 0.5f,  0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  1.0f,  0.0f,
		 0.5f,  0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  1.0f,  1.0f,
		 0.6f, -0.0f, -0.5f,  1.0f,  0.0f,  0.0f,  0.0f,  1.0f,

		 0.6f, -0.0f, -0.5f,  1.0f,  0.0f,  0.0f,  0.0f,  1.0f,
		 0.6f, -0.0f,  0.5f,  1.0f,  0.0f,  0.0f,  0.0f,  0.0f,
		 0.5f,  0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  1.0f,  0.0f,


		 //right side-bottom
		 0.6f,  0.0f,  0.5f,  1.0f,  0.0f,  0.0f,  1.0f,  0.0f,
		 0.6f,  0.0f, -0.5f,  1.0f,  0.0f,  0.0f,  1.0f,  1.0f,
		 0.5f, -0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  0.0f,  1.0f,

		 0.5f, -0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  0.0f,  1.0f,
		 0.5f, -0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  0.0f,  0.0f,
		 0.6f,  0.0f,  0.5f,  1.0f,  0.0f,  0.0f,  1.0f,  0.0f,



		 //bottom side
		 -0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,  0.0f,  1.0f,
		  0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,  1.0f,  1.0f,
		  0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,  1.0f,  0.0f,
		  0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,  1.0f,  0.0f,
		 -0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,  0.0f,  0.0f,
		 -0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,  0.0f,  1.0f,

		 //top side
		 -0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,  0.0f,  1.0f,
		  0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,  1.0f,  1.0f,
		  0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,  1.0f,  0.0f,
		  0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,  1.0f,  0.0f,
		 -0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,  0.0f,  0.0f,
		 -0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,  0.0f,  1.0f
};

	unsigned int stickHolderVBO, stickHolderVAO;

	glGenVertexArrays(1, &stickHolderVAO);
	glGenBuffers(1, &stickHolderVBO);

	glBindVertexArray(stickHolderVAO);
	glBindBuffer(GL_ARRAY_BUFFER, stickHolderVBO);
	glBufferData(GL_ARRAY_BUFFER, stickHolderVertices.size() * sizeof(float), &stickHolderVertices[0], GL_STATIC_DRAW);

	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);

	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);

	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
	glEnableVertexAttribArray(2);

	auto floorTexture = loadTexture("floor.jpg");
	auto cubeTexture = loadTexture("design.jpg");
	auto designTexture = loadTexture("design1.jpg");
	auto woodTexture = loadTexture("wood.jpg");
	auto tissueTexture = loadTexture("tissue.jpg");
	auto flowerDesignTexture = loadTexture("flower-design.jpg");

	lightingShader.use();
	lightingShader.setInt("material.diffuse", 0);

	glActiveTexture(GL_TEXTURE0);

	while (!glfwWindowShouldClose(window))
	{
		float currentFrame = glfwGetTime();
		deltaTime = currentFrame - lastFrame;
		lastFrame = currentFrame;

		processInput(window);

		glClearColor(0.1f, 0.1f, 0.1f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);



		lightingShader.setVec3("viewPos", camera.Position);
		lightingShader.setFloat("material.shininess", 32.0f);

		// directional light
		lightingShader.setVec3("dirLight.direction", -0.2f, -1.0f, -0.3f);
		lightingShader.setVec3("dirLight.ambient", 0.05f, 0.05f, 0.05f);
		lightingShader.setVec3("dirLight.diffuse", 0.4f, 0.4f, 0.4f);
		lightingShader.setVec3("dirLight.specular", 0.5f, 0.5f, 0.5f);
		lightingShader.setFloat("dirLight.intensity", 1.0f);

		// point light 1
		lightingShader.setVec3("pointLights[0].position", glm::vec3(0.0f, 3.0f, 0.0f));
		lightingShader.setVec3("pointLights[0].ambient", 0.05f, 0.05f, 0.05f);
		lightingShader.setVec3("pointLights[0].diffuse", 0.8f, 0.8f, 0.8f);
		lightingShader.setVec3("pointLights[0].specular", 1.0f, 1.0f, 1.0f);
		lightingShader.setFloat("pointLights[0].constant", 1.0f);
		lightingShader.setFloat("pointLights[0].linear", 0.09);
		lightingShader.setFloat("pointLights[0].quadratic", 0.032);
		lightingShader.setFloat("pointLights[0].intensity", 1.0f);

		// point light 2
		lightingShader.setVec3("pointLights[1].position", glm::vec3(-8.0f, 3.0f, -8.0f));
		lightingShader.setVec3("pointLights[1].ambient", 0.05f, 0.05f, 0.05f);
		lightingShader.setVec3("pointLights[1].diffuse", 0.8f, 0.8f, 0.0f);
		lightingShader.setVec3("pointLights[1].specular", 0.8f, 0.8f, 0.0f);
		lightingShader.setFloat("pointLights[1].constant", 1.0f);
		lightingShader.setFloat("pointLights[1].linear", 0.09);
		lightingShader.setFloat("pointLights[1].quadratic", 0.032);
		lightingShader.setFloat("pointLights[1].intensity", 1.0f);

		// point light 3
		lightingShader.setVec3("pointLights[2].position", glm::vec3(8.0f, 3.0f, -8.0f));
		lightingShader.setVec3("pointLights[2].ambient", 0.05f, 0.05f, 0.05f);
		lightingShader.setVec3("pointLights[2].diffuse", 0.0f, 0.0f, 0.8f);
		lightingShader.setVec3("pointLights[2].specular", 0.0f, 0.0f, 0.8f);
		lightingShader.setFloat("pointLights[2].constant", 1.0f);
		lightingShader.setFloat("pointLights[2].linear", 0.09);
		lightingShader.setFloat("pointLights[2].quadratic", 0.032);
		lightingShader.setFloat("pointLights[2].intensity", 1.0f);

		// point light 4
		lightingShader.setVec3("pointLights[3].position", glm::vec3(-8.0f, 3.0f, 8.0f));
		lightingShader.setVec3("pointLights[3].ambient", 0.05f, 0.05f, 0.05f);
		lightingShader.setVec3("pointLights[3].diffuse", 0.0f, 0.8f, 0.0f);
		lightingShader.setVec3("pointLights[3].specular", 0.0f, 0.8f, 0.0f);
		lightingShader.setFloat("pointLights[3].constant", 1.0f);
		lightingShader.setFloat("pointLights[3].linear", 0.09);
		lightingShader.setFloat("pointLights[3].quadratic", 0.032);
		lightingShader.setFloat("pointLights[3].intensity", 1.0f);

		// point light 5
		lightingShader.setVec3("pointLights[4].position", glm::vec3(8.0f, 3.0f, 8.0f));
		lightingShader.setVec3("pointLights[4].ambient", 0.05f, 0.05f, 0.05f);
		lightingShader.setVec3("pointLights[4].diffuse", 0.8f, 0.0f, 0.0f);
		lightingShader.setVec3("pointLights[4].specular", 0.8f, 0.0f, 0.0f);
		lightingShader.setFloat("pointLights[4].constant", 1.0f);
		lightingShader.setFloat("pointLights[4].linear", 0.09);
		lightingShader.setFloat("pointLights[4].quadratic", 0.032);
		lightingShader.setFloat("pointLights[4].intensity", 1.0f);



		glm::mat4 projection = glm::mat4(1.0);

		// view/projection transformations
		if (isOrtho)
		{
			float zoomFactor = 0.5f;

			float left = -zoomFactor * (float)SCR_WIDTH / 2.0f;
			float right = zoomFactor * (float)SCR_WIDTH / 2.0f;
			float bottom = -zoomFactor * (float)SCR_HEIGHT / 2.0f;
			float top = zoomFactor * (float)SCR_HEIGHT / 2.0f;

			glm::mat4 projection = glm::ortho(left, right, bottom, top, 0.1f, 1000.0f);
		}
		else
		{
			projection = glm::perspective(glm::radians(camera.Zoom), (float)SCR_WIDTH / (float)SCR_HEIGHT, 0.1f, 100.0f);
		}

		glm::mat4 view = camera.GetViewMatrix();
		lightingShader.setMat4("projection", projection);
		lightingShader.setMat4("view", view);

		glm::mat4 model = glm::mat4(1.0f);

		//plane
		{
			glBindVertexArray(planeVAO);
			lightingShader.setInt("hasTexture", 1);
			glBindTexture(GL_TEXTURE_2D, floorTexture);

			model = glm::mat4(1.0f);
			model = glm::scale(model, glm::vec3(8.0f));
			lightingShader.setMat4("model", model);
			glDrawElements(GL_TRIANGLES, planeVertexCount, GL_UNSIGNED_INT, 0);
		}

		//misc box
		{
			glBindVertexArray(cubeVAO);
			lightingShader.setInt("hasTexture", 1);

			glBindTexture(GL_TEXTURE_2D, designTexture);

			//top plane
			model = glm::mat4(1.0f);
			model = glm::translate(model, glm::vec3(0.5f, 0.3f, 0.15f));
			model = glm::scale(model, glm::vec3(0.4f, 0.03f, 0.4f));
			lightingShader.setMat4("model", model);
			glDrawArrays(GL_TRIANGLES, 0, cubeVertexCount);

			glBindTexture(GL_TEXTURE_2D, woodTexture);

			//left plane
			model = glm::mat4(1.0f);
			model = glm::translate(model, glm::vec3(0.3f, 0.28f, 0.15f));
			model = glm::rotate(model, glm::radians(90.0f), glm::vec3(0.0f, 0.0f, 1.0f));
			model = glm::scale(model, glm::vec3(0.15f, 0.005f, 0.45f));
			lightingShader.setMat4("model", model);
			glDrawArrays(GL_TRIANGLES, 0, cubeVertexCount);

			//right plane
			model = glm::mat4(1.0f);
			model = glm::translate(model, glm::vec3(0.7f, 0.28f, 0.15f));
			model = glm::rotate(model, glm::radians(90.0f), glm::vec3(0.0f, 0.0f, 1.0f));
			model = glm::scale(model, glm::vec3(0.15f, 0.005f, 0.45f));
			lightingShader.setMat4("model", model);
			glDrawArrays(GL_TRIANGLES, 0, cubeVertexCount);

			//front plane
			model = glm::mat4(1.0f);
			model = glm::translate(model, glm::vec3(0.5f, 0.28f, 0.35f));
			model = glm::rotate(model, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
			model = glm::scale(model, glm::vec3(0.45f, 0.005f, 0.15f));
			lightingShader.setMat4("model", model);
			glDrawArrays(GL_TRIANGLES, 0, cubeVertexCount);

			//back plane
			model = glm::mat4(1.0f);
			model = glm::translate(model, glm::vec3(0.5f, 0.28f, -0.05f));
			model = glm::rotate(model, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
			model = glm::scale(model, glm::vec3(0.45f, 0.005f, 0.15f));
			lightingShader.setMat4("model", model);
			glDrawArrays(GL_TRIANGLES, 0, cubeVertexCount);

		}





		//tissue box
		{
			glBindVertexArray(cubeVAO);
			lightingShader.setInt("hasTexture", 1);

			glBindTexture(GL_TEXTURE_2D, cubeTexture);

			model = glm::mat4(1.0f);
			model = glm::translate(model, glm::vec3(-0.5f, 0.46f, 0.15f));
			model = glm::scale(model, glm::vec3(0.5f));
			model = glm::rotate(model, glm::radians(-45.0f), glm::vec3(0.0f, 1.0f, 0.0f));
			lightingShader.setMat4("model", model);
			glDrawArrays(GL_TRIANGLES, 0, cubeVertexCount);
		}
		



		

		//table
		{
			glBindVertexArray(cylinderVAO);
			lightingShader.setInt("hasTexture", 0);

			//along z
			model = glm::mat4(1.0f);
			model = glm::translate(model, glm::vec3(0.0f, 0.05f, 0.5f));
			model = glm::scale(model, glm::vec3(0.05f, 0.1f, 0.05f));
			model = glm::rotate(model, glm::radians(90.0f), glm::vec3(-1.0f, 0.0f, 0.0f));
			lightingShader.setVec3("meshColor", glm::vec3(0.2549f, 0.2666f, 0.1450f));
			lightingShader.setMat4("model", model);
			glDrawElements(GL_TRIANGLES, cylinderVertexCount, GL_UNSIGNED_INT, (void*)0);

			//top left
			model = glm::mat4(1.0f);
			model = glm::translate(model, glm::vec3(-0.5f, 0.05f, -0.5f));
			model = glm::scale(model, glm::vec3(0.05f, 0.1f, 0.05f));
			model = glm::rotate(model, glm::radians(90.0f), glm::vec3(-1.0f, 0.0f, 0.0f));
			lightingShader.setMat4("model", model);
			glDrawElements(GL_TRIANGLES, cylinderVertexCount, GL_UNSIGNED_INT, (void*)0);

			//top right
			model = glm::mat4(1.0f);
			model = glm::translate(model, glm::vec3(0.5f, 0.05f, -0.5f));
			model = glm::scale(model, glm::vec3(0.05f, 0.1f, 0.05f));
			model = glm::rotate(model, glm::radians(90.0f), glm::vec3(-1.0f, 0.0f, 0.0f));
			lightingShader.setMat4("model", model);
			glDrawElements(GL_TRIANGLES, cylinderVertexCount, GL_UNSIGNED_INT, (void*)0);

			lightingShader.setInt("hasTexture", 1);
			glBindTexture(GL_TEXTURE_2D, flowerDesignTexture);

			//base
			model = glm::mat4(1.0f);
			model = glm::translate(model, glm::vec3(0.0f, 0.15f, 0.0f));
			model = glm::scale(model, glm::vec3(0.8f, 0.1f, 0.8f));
			model = glm::rotate(model, glm::radians(90.0f), glm::vec3(-1.0f, 0.0f, 0.0f));
			lightingShader.setMat4("model", model);
			glDrawElements(GL_TRIANGLES, cylinderVertexCount, GL_UNSIGNED_INT, (void*)0);
		}
		


		//Tissue roll
		{
			glBindVertexArray(cylinderVAO);
			lightingShader.setInt("hasTexture", 1);

			glBindTexture(GL_TEXTURE_2D, tissueTexture);

			//Middle
			model = glm::mat4(1.0f);
			model = glm::translate(model, glm::vec3(1.0, 0.4f, 0.0f));
			model = glm::scale(model, glm::vec3(0.15f, 0.8f, 0.15f));
			model = glm::rotate(model, glm::radians(90.0f), glm::vec3(-1.0f, 0.0f, 0.0f));
			lightingShader.setVec3("meshColor", glm::vec3(1.0));
			lightingShader.setMat4("model", model);
			glDrawElements(GL_TRIANGLES, cylinderVertexCount, GL_UNSIGNED_INT, (void*)0);

			lightingShader.setInt("hasTexture", 0);

			//Top
			model = glm::mat4(1.0f);
			model = glm::translate(model, glm::vec3(1.0, 0.85f, 0.0f));
			model = glm::scale(model, glm::vec3(0.05f, 0.1f, 0.05f));
			model = glm::rotate(model, glm::radians(90.0f), glm::vec3(-1.0f, 0.0f, 0.0f));
			lightingShader.setVec3("meshColor", glm::vec3(0.7));
			lightingShader.setMat4("model", model);
			glDrawElements(GL_TRIANGLES, cylinderVertexCount, GL_UNSIGNED_INT, (void*)0);

			//Base
			model = glm::mat4(1.0f);
			model = glm::translate(model, glm::vec3(1.0f, 0.05f, 0.0f));
			model = glm::scale(model, glm::vec3(0.25f, 0.1f, 0.25f));
			model = glm::rotate(model, glm::radians(90.0f), glm::vec3(-1.0f, 0.0f, 0.0f));
			lightingShader.setVec3("meshColor", glm::vec3(0.2));
			lightingShader.setMat4("model", model);
			glDrawElements(GL_TRIANGLES, cylinderVertexCount, GL_UNSIGNED_INT, (void*)0);
		}
		
		glfwSwapBuffers(window);
		glfwPollEvents();
	}


	glfwTerminate();
	return 0;
}

void processInput(GLFWwindow* window)
{
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		glfwSetWindowShouldClose(window, true);

	if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
		camera.ProcessKeyboard(FORWARD, deltaTime);
	if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
		camera.ProcessKeyboard(BACKWARD, deltaTime);
	if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
		camera.ProcessKeyboard(LEFT, deltaTime);
	if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
		camera.ProcessKeyboard(RIGHT, deltaTime);
	if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
		camera.ProcessKeyboard(UP, deltaTime);
	if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
		camera.ProcessKeyboard(DOWN, deltaTime);
}

void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
	glViewport(0, 0, width, height);
}

void mouse_callback(GLFWwindow* window, double xpos, double ypos)
{
	if (firstMouse)
	{
		lastX = xpos;
		lastY = ypos;
		firstMouse = false;
	}

	float xoffset = xpos - lastX;
	float yoffset = lastY - ypos;

	lastX = xpos;
	lastY = ypos;

	camera.ProcessMouseMovement(xoffset, yoffset);
}

void scroll_callback(GLFWwindow* window, double xoffset, double yoffset)
{
	camera.ProcessMouseScroll(yoffset);
}

unsigned int loadTexture(char const* path)
{
	unsigned int textureID;
	glGenTextures(1, &textureID);

	int width, height, nrComponents;
	unsigned char* data = stbi_load(path, &width, &height, &nrComponents, 0);
	if (data)
	{
		GLenum format;
		if (nrComponents == 1)
			format = GL_RED;
		else if (nrComponents == 3)
			format = GL_RGB;
		else if (nrComponents == 4)
			format = GL_RGBA;

		glBindTexture(GL_TEXTURE_2D, textureID);
		glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0, format, GL_UNSIGNED_BYTE, data);
		glGenerateMipmap(GL_TEXTURE_2D);

		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		stbi_image_free(data);
	}
	else
	{
		std::cout << "Texture failed to load at path: " << path << std::endl;
		stbi_image_free(data);
	}

	return textureID;
}